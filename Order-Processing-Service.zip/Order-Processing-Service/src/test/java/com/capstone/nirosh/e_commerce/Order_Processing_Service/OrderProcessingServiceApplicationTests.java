package com.capstone.nirosh.e_commerce.Order_Processing_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderProcessingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
