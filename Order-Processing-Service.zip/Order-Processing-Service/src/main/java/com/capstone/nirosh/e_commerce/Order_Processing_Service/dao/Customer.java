package com.capstone.nirosh.e_commerce.Order_Processing_Service.dao;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Customer {

    private Long id;
    private String name;

}
