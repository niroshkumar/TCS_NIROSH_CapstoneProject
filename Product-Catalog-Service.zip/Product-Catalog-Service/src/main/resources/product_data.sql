INSERT INTO products (name, description, price, category) VALUES ('Laptop', 'A high-performance laptop', 1200.00, 'Electronics'),
                                                              ('Smartphone', 'Latest model smartphone', 800.00, 'Electronics'),
                                                              ('Chair', 'Comfortable office chair', 150.00, 'Furniture');
