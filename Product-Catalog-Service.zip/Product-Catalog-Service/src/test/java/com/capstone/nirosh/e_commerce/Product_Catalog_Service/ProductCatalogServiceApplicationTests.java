package com.capstone.nirosh.e_commerce.Product_Catalog_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
