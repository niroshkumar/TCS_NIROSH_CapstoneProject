package com.capstone.nirosh.e_commerce.Customer_Service.controller;

import com.capstone.nirosh.e_commerce.Customer_Service.ExceptionHandling.ResourceNotFoundException;
import com.capstone.nirosh.e_commerce.Customer_Service.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.capstone.nirosh.e_commerce.Customer_Service.repository.CustomerRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerRepository repository;

    @GetMapping("/{id}")
    public Customer getCustomer(@PathVariable Long id) {
        Optional<Customer> customer = repository.findById(id);
        if (customer.isPresent()) {
            return customer.get();
        } else {
            throw new ResourceNotFoundException("Customer Not found");
        }
    }

    @GetMapping()
    public List<Customer> getCustomer() {
        List<Customer> customerList = repository.findAll();
        if (customerList.size() > 0) {
            return customerList;
        } else {
            throw new ResourceNotFoundException("Customers Not found");
        }
    }

    @PostMapping()
    public Customer createCustomer(@RequestBody Customer customer) {
        return repository.save(customer);
    }

    @PutMapping("/{id}")
    public Customer updateCustomer(@RequestBody Customer customer,@PathVariable Long id) {
        Optional<Customer> customerdata = repository.findById(id);
        if (customerdata.isPresent()) {
            Customer customer1=new Customer();
            customer1.setId(id);
            customer1.setName(customer.getName());
            return repository.save(customer1);
        } else {
            throw new ResourceNotFoundException("Customer Not found");
        }
    }

    @DeleteMapping("/{id}")
    public Customer delCustomer(@PathVariable Long id) {
        Optional<Customer> customer = repository.findById(id);
        if (customer.isPresent()) {
            repository.deleteById(customer.get().getId());
        } else {
            throw new ResourceNotFoundException("Customer Not found");
        }
        return customer.get();
    }

}